# SplaTu
An image conversion tool for Splatoon2 posts

This project was based on shinyquagsire23's Switch-FightStick Splatoon 2 Posts Project: github.com/shinyquagsire23/Switch-Fightstick 
The application SplaTu contains an image converter, which converts any image to a 320x120 monochrome bitmap, then converts the bitmap to image.c and eventually use shinyquagsire23's project to generate Joystick.h

Download: http://pan.baidu.com/s/1i5bzZm9 
Download password: ynwg


![Screenshot](https://s11.postimg.org/j7rbrj9s3/zelda.png)




